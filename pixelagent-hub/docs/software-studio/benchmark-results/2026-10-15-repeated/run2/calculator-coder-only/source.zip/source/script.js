'use strict';

const leftInput = document.getElementById('left');
const rightInput = document.getElementById('right');
const operationSelect = document.getElementById('operation');
const calculateButton = document.getElementById('calculate');
const resultOutput = document.getElementById('result');

function calculate() {
  const left = leftInput.value.trim();
  const right = rightInput.value.trim();

  if (left === '' || right === '') {
    resultOutput.textContent = 'Error';
    return;
  }

  const leftNumber = Number(left);
  const rightNumber = Number(right);

  if (!Number.isFinite(leftNumber) || !Number.isFinite(rightNumber)) {
    resultOutput.textContent = 'Error';
    return;
  }

  if (operationSelect.value === 'divide' && rightNumber === 0) {
    resultOutput.textContent = 'Error';
    return;
  }

  let value;
  switch (operationSelect.value) {
    case 'add':
      value = leftNumber + rightNumber;
      break;
    case 'subtract':
      value = leftNumber - rightNumber;
      break;
    case 'multiply':
      value = leftNumber * rightNumber;
      break;
    case 'divide':
      value = leftNumber / rightNumber;
      break;
    default:
      resultOutput.textContent = 'Error';
      return;
  }

  if (!Number.isFinite(value)) {
    resultOutput.textContent = 'Error';
    return;
  }

  resultOutput.textContent = String(value);
}

calculateButton.addEventListener('click', calculate);