# Pixel Calculator

A tiny offline pixel-style two-number calculator built with HTML, CSS, and JavaScript.

## Files

- `index.html` - page structure and labeled controls
- `style.css` - pixel-style layout and responsive design
- `script.js` - validation and calculation logic
- `README.md` - this file

## Usage

Open `index.html` in any modern browser. No server, packages, or network access required.

1. Enter a left number.
2. Enter a right number.
3. Choose an operation.
4. Click **Calculate** or press Enter while the button is focused.

## Behavior

- Supports positive, negative, decimal, and exponent-style numeric input.
- Empty or non-finite input shows `Error`.
- Division by zero shows `Error`.
- The result area starts at `0` and contains only the numeric result or `Error`.

## Element IDs
`left`, `right`, `operation`, `calculate`, `result`.