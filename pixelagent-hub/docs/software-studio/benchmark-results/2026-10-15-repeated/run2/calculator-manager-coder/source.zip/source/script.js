const left = document.getElementById('left');
const right = document.getElementById('right');
const operation = document.getElementById('operation');
const result = document.getElementById('result');

function readNumber(input) {
  const raw = input.value.trim();
  if (raw === '') return null;
  const num = Number(raw);
  return Number.isFinite(num) ? num : null;
}

document.getElementById('calculate').addEventListener('click', () => {
  const a = readNumber(left);
  const b = readNumber(right);

  if (a === null || b === null) {
    result.textContent = 'Error';
    return;
  }

  if (operation.value === 'divide' && b === 0) {
    result.textContent = 'Error';
    return;
  }

  let answer;
  switch (operation.value) {
    case 'add':
      answer = a + b;
      break;
    case 'subtract':
      answer = a - b;
      break;
    case 'multiply':
      answer = a * b;
      break;
    case 'divide':
      answer = a / b;
      break;
    default:
      result.textContent = 'Error';
      return;
  }

  result.textContent = String(answer);
});
