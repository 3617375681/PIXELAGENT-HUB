# Pixel Two-Number Calculator

A tiny offline calculator with a pixel-art style. Open `index.html` in any modern browser.

## Features

- Four operations: add, subtract, multiply, divide.
- Supports negative numbers.
- Displays the result as a number only, or exactly `Error` for invalid input.
- Invalid cases: empty fields, non-finite numbers, and division by zero.
- Keyboard-accessible labeled controls.

## Files

- `index.html`: page structure
- `styles.css`: pixel-style visual design
- `script.js`: calculator logic and validation

No dependencies, network access, or storage are required.
