# Pixel Quiz

A tiny offline two-question quiz built with HTML, CSS, and plain JavaScript. No packages, network requests, or storage are used.

## How to run
1. Open `index.html` in any modern web browser.
2. Read the question, then click either **Answer A** or **Answer B**.
3. The first correct answer adds 1 to the score. Answers lock after your choice.
4. Click **Next** to move to the second question, then click **Next** again to finish.
5. Click **Restart** at any time to return to the first question and reset the score.

## Controls
- `Answer A` / `Answer B`: choose an answer.
- `Next`: advance to the next question or finish.
- `Restart`: reset the quiz.

## Files
- `index.html` — page structure and labels
- `styles.css` — pixel-style presentation
- `script.js` — quiz state and event handling