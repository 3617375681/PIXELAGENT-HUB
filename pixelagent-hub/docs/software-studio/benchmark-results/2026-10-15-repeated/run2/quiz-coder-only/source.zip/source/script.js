(function () {
  'use strict';

  var questions = [
    { question: '2 + 2 = ?', answers: ['4', '5'], correctIndex: 0 },
    { question: '3 + 3 = ?', answers: ['5', '6'], correctIndex: 1 }
  ];

  var questionEl = document.getElementById('question');
  var answerA = document.getElementById('answer-a');
  var answerB = document.getElementById('answer-b');
  var scoreEl = document.getElementById('score');
  var nextBtn = document.getElementById('next');
  var restartBtn = document.getElementById('restart');

  var currentIndex = 0;
  var answered = false;
  var score = 0;

  function setScore(value) {
    score = Math.floor(Number(value)) || 0;
    scoreEl.textContent = score;
  }

  function renderCurrentQuestion() {
    var q = questions[currentIndex];
    questionEl.textContent = q.question;
    answerA.textContent = q.answers[0];
    answerB.textContent = q.answers[1];
    answerA.disabled = false;
    answerB.disabled = false;
    answered = false;
  }

  function lockAnswers() {
    answerA.disabled = true;
    answerB.disabled = true;
    answered = true;
  }

  function handleAnswer(index) {
    if (answered) return;
    lockAnswers();
    if (questions[currentIndex].correctIndex === index) {
      setScore(score + 1);
    }
  }

  answerA.addEventListener('click', function () {
    handleAnswer(0);
  });

  answerB.addEventListener('click', function () {
    handleAnswer(1);
  });

  nextBtn.addEventListener('click', function () {
    if (currentIndex < questions.length - 1) {
      currentIndex += 1;
      renderCurrentQuestion();
    } else {
      questionEl.textContent = 'Finished';
      answerA.disabled = true;
      answerB.disabled = true;
      answered = true;
    }
  });

  restartBtn.addEventListener('click', function () {
    currentIndex = 0;
    setScore(0);
    renderCurrentQuestion();
  });

  renderCurrentQuestion();
})();