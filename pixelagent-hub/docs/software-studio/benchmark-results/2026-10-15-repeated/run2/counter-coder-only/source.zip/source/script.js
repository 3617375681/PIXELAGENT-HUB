const countEl = document.getElementById('count');
let count = 0;

function update() {
  countEl.textContent = count;
}

document.getElementById('increase').addEventListener('click', () => {
  count += 1;
  update();
});

document.getElementById('decrease').addEventListener('click', () => {
  count -= 1;
  update();
});

document.getElementById('reset').addEventListener('click', () => {
  count = 0;
  update();
});