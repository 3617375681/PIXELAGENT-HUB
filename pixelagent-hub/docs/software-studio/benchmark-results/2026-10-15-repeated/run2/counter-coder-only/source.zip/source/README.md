# Pixel Counter

An offline pixel-style counter built with HTML, CSS, and vanilla JavaScript.

## Usage
- Open `index.html` in any modern browser.
- Use mouse or keyboard: `Tab` + `Enter`/`Space` on buttons.
- **Increase** adds 1.
- **Decrease** subtracts 1.
- **Reset** returns to 0.
- Supports negative numbers.

## Files
- `index.html` - page structure
- `style.css` - pixel styling
- `script.js` - counter logic

No dependencies, storage, or network required.