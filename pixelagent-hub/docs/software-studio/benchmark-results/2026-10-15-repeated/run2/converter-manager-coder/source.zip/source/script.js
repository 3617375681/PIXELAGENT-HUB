const form = document.getElementById('temp-form');
const temperature = document.getElementById('temperature');
const direction = document.getElementById('direction');
const result = document.getElementById('result');
const formula = document.getElementById('formula');

const converters = {
  'c-to-f': {
    text: 'Formula: °F = °C × 9/5 + 32',
    convert: (x) => x * 9 / 5 + 32
  },
  'f-to-c': {
    text: 'Formula: °C = (°F - 32) × 5/9',
    convert: (x) => (x - 32) * 5 / 9
  }
};

function updateFormula() {
  formula.textContent = converters[direction.value].text;
}

direction.addEventListener('change', updateFormula);
updateFormula();

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const raw = temperature.value.trim();

  if (raw === '' || !Number.isFinite(Number(raw))) {
    result.textContent = 'Error';
    result.classList.add('error');
    return;
  }

  const value = Number(raw);
  const converted = converters[direction.value].convert(value);

  if (!Number.isFinite(converted)) {
    result.textContent = 'Error';
    result.classList.add('error');
    return;
  }

  result.textContent = converted.toFixed(2);
  result.classList.remove('error');
});