# Pixel Temperature Converter

An offline, pixel-styled temperature converter built with plain HTML, CSS, and JavaScript.

## Usage
1. Open `index.html` in any modern browser.
2. Enter a temperature number.
3. Choose conversion direction: Celsius to Fahrenheit or Fahrenheit to Celsius.
4. Click Convert or press Enter.
5. The result appears with exactly two decimal places. Invalid or empty input shows `Error`.

## Formulas
- Celsius to Fahrenheit: `°F = °C × 9/5 + 32`
- Fahrenheit to Celsius: `°C = (°F - 32) × 5/9`

## Files
- `index.html` - markup and controls
- `styles.css` - pixel-style layout and focus states
- `script.js` - conversion and validation logic
- `README.md` - project documentation

## Constraints
- Offline only; no external assets, packages, or network requests.
- No inline event handlers.
- Keyboard-accessible labeled controls.