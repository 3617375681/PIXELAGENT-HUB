# Pixel Temperature Converter

An offline, keyboard-accessible temperature converter with a chunky pixel look.

## How to run
Open `index.html` in any modern browser.

## Features
- Enter a numeric temperature and choose a conversion direction.
- Click **Convert** or press **Enter** while the input or select is focused.
- Results use exactly two decimal places and no units.
- Empty, invalid, or non-finite input shows exactly `Error`.

## Formulas
- C to F: `x * 9 / 5 + 32`
- F to C: `(x - 32) * 5 / 9`

## Files
- `index.html` - semantic structure and labels
- `styles.css` - pixel-style layout and focus states
- `script.js` - conversion logic and event listeners

No packages, storage, network access, or external assets are used.
