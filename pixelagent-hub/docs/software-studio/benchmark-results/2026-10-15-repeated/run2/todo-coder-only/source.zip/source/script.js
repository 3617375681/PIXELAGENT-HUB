(() => {
  'use strict';

  const form = document.getElementById('todo-form');
  const input = document.getElementById('todo-input');
  const list = document.getElementById('todo-list');
  const totalEl = document.getElementById('todo-total');
  const remainingEl = document.getElementById('remaining');

  let nextId = 1;
  let total = 0;
  let remaining = 0;

  const updateCounts = () => {
    totalEl.textContent = String(total);
    remainingEl.textContent = String(remaining);
  };

  const addTask = (text) => {
    const id = nextId++;
    const li = document.createElement('li');
    li.id = `todo-item-${id}`;

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.id = `todo-check-${id}`;
    checkbox.setAttribute('aria-label', `Task ${id} completed`);

    const span = document.createElement('span');
    span.id = `todo-text-${id}`;
    span.textContent = text;

    const del = document.createElement('button');
    del.type = 'button';
    del.id = `todo-delete-${id}`;
    del.textContent = 'Delete';
    del.setAttribute('aria-label', `Delete task ${id}`);

    li.append(checkbox, span, del);
    list.appendChild(li);

    total += 1;
    remaining += 1;
    updateCounts();

    checkbox.addEventListener('change', () => {
      const isChecked = checkbox.checked;
      remaining += isChecked ? -1 : 1;
      li.classList.toggle('task-done', isChecked);
      updateCounts();
    });

    del.addEventListener('click', () => {
      li.remove();
      total -= 1;
      if (!checkbox.checked) {
        remaining -= 1;
      }
      updateCounts();
    });
  };

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const text = input.value.trim();
    if (text === '') return;
    addTask(text);
    input.value = '';
    input.focus();
  });

  updateCounts();
})();