# Pixel Tasks

An offline pixel-style task list built with plain HTML, CSS, and JavaScript.

## Features
- Add tasks with the input and **Add** button.
- Task IDs increase with each added task.
- Checkbox toggles a task complete and updates the remaining count.
- Delete removes a task and updates total/remaining counts.
- Counts stay in memory only; no storage or network needed.

## Files
- `index.html` - page structure
- `styles.css` - pixel-style appearance
- `script.js` - task state and DOM behavior

## Usage
Open `index.html` in any modern browser. Works fully offline.