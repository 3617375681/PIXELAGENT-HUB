# Pixel Counter

An offline, dependency-free pixel-style counter.

## Features
- Starts at 0 and shows only the integer.
- Increase, decrease, and reset buttons.
- Supports negative numbers.
- Keyboard-accessible labeled buttons with visible focus.
- No dependencies, storage, or network requests.

## Run
Open `index.html` in any modern web browser. Works fully offline.