const count = document.getElementById('count');
const increase = document.getElementById('increase');
const decrease = document.getElementById('decrease');
const reset = document.getElementById('reset');

let value = 0;

function render() {
  count.textContent = value;
}

increase.addEventListener('click', () => {
  value += 1;
  render();
});

decrease.addEventListener('click', () => {
  value -= 1;
  render();
});

reset.addEventListener('click', () => {
  value = 0;
  render();
});

render();