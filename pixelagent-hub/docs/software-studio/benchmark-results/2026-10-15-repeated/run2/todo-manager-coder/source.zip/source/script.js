const input = document.getElementById('todo-input');
const addBtn = document.getElementById('todo-add');
const list = document.getElementById('todo-list');
const totalEl = document.getElementById('todo-total');
const remainingEl = document.getElementById('remaining');

let tasks = [];
let nextId = 1;

function updateCounts() {
  totalEl.textContent = tasks.length;
  remainingEl.textContent = tasks.filter(task => !task.completed).length;
}

function render() {
  list.innerHTML = '';

  tasks.forEach(task => {
    const li = document.createElement('li');
    li.className = 'todo-item' + (task.completed ? ' done' : '');

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.id = `todo-check-${task.id}`;
    checkbox.checked = task.completed;
    checkbox.setAttribute('aria-label', 'Mark task complete');

    const text = document.createElement('span');
    text.id = `todo-text-${task.id}`;
    text.textContent = task.text;

    const deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.id = `todo-delete-${task.id}`;
    deleteBtn.textContent = 'Delete';
    deleteBtn.setAttribute('aria-label', 'Delete task');

    checkbox.addEventListener('change', () => {
      task.completed = checkbox.checked;
      li.classList.toggle('done', task.completed);
      updateCounts();
    });

    deleteBtn.addEventListener('click', () => {
      tasks = tasks.filter(t => t.id !== task.id);
      render();
    });

    li.append(checkbox, text, deleteBtn);
    list.appendChild(li);
  });

  updateCounts();
}

function addTask() {
  const text = input.value.trim();
  if (!text) return;

  tasks.push({ id: nextId, text, completed: false });
  nextId += 1;
  input.value = '';
  render();
}

addBtn.addEventListener('click', addTask);
input.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    addTask();
  }
});