# Offline Pixel Task List

A lightweight, offline task list with retro pixel styling. No packages, no storage, no network requests.

## Run
Open `index.html` in any modern browser.

## Features
- Add tasks with `#todo-input` and `#todo-add`
- Blank input adds nothing; text is trimmed
- First task receives IDs `#todo-text-1`, `#todo-check-1`, `#todo-delete-1`
- New tasks increment numeric IDs; IDs are never reused
- Total task count in `#todo-total`, incomplete count in `#remaining`
- Toggling checkboxes updates incomplete count
- Deleting a task removes it and updates both counts
- All state is kept in memory only

## Acceptance
- Open index.html
- Initially both counts show `0`
- Add `  ` -> nothing added
- Add `Paint fence` -> total 1, remaining 1
- Toggle checkbox -> total 1, remaining 0
- Add `Write docs` -> total 2, remaining 1
- Delete first task -> total 1, remaining 0 (if second unchecked)