# Pixel Temperature Converter

An offline, pixel-style temperature converter built with plain HTML, CSS, and JavaScript.

## Usage

1. Open `index.html` in a modern browser.
2. Enter a numeric temperature.
3. Choose conversion direction: Celsius to Fahrenheit or Fahrenheit to Celsius.
4. Click Convert or press Enter.
5. The output shows the result with exactly two decimals, or `Error` for empty/invalid/non-finite input.

## Formulas

- Celsius to Fahrenheit: `F = C × 9/5 + 32`
- Fahrenheit to Celsius: `C = (F - 32) × 5/9`

## Files

- `index.html` - App structure and accessible labeled controls
- `style.css` - Pixel-inspired styling and focus states
- `script.js` - Conversion and validation logic

No dependencies, packages, network requests, external assets, iframes, or server code are used.