const tempInput = document.getElementById('temperature');
const direction = document.getElementById('direction');
const convertBtn = document.getElementById('convert');
const result = document.getElementById('result');
const formula = document.getElementById('formula');

function updateFormula() {
  formula.textContent = direction.value === 'c-to-f'
    ? 'F = C × 9/5 + 32'
    : 'C = (F - 32) × 5/9';
}

function convert() {
  const raw = tempInput.value.trim();
  if (raw === '') {
    result.textContent = 'Error';
    return;
  }
  const temp = Number(raw);
  if (!Number.isFinite(temp)) {
    result.textContent = 'Error';
    return;
  }
  const output = direction.value === 'c-to-f'
    ? temp * 9 / 5 + 32
    : (temp - 32) * 5 / 9;
  result.textContent = output.toFixed(2);
}

convertBtn.addEventListener('click', convert);
direction.addEventListener('change', updateFormula);
tempInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') convert();
});

updateFormula();