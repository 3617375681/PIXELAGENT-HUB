# Offline Pixel Task List

Open `index.html` in any modern browser. No server, network, or build step required.

## Features
- Add tasks by typing and clicking Add or pressing Enter.
- Blank input is ignored after trimming.
- Pixel-style CSS with hard borders and shadows.
- Total and remaining counts update instantly and stay integer-only.
- Toggle checkboxes to mark tasks done.
- Delete buttons remove individual tasks.
- First task gets IDs `todo-text-1`, `todo-check-1`, `todo-delete-1`.
- State is kept in memory only; refreshing clears tasks.

## Files
- `index.html` – page structure and labels
- `styles.css` – pixel-style visual design
- `script.js` – in-memory task state and DOM updates
- `README.md` – this file