(() => {
  const input = document.getElementById('todo-input');
  const addBtn = document.getElementById('todo-add');
  const totalEl = document.getElementById('todo-total');
  const remainingEl = document.getElementById('remaining');
  const listEl = document.getElementById('todo-list');
  const tasks = [];
  let nextId = 1;

  const updateCounts = () => {
    totalEl.textContent = String(tasks.length);
    remainingEl.textContent = String(tasks.filter(t => !t.done).length);
  };

  const renderTask = (task) => {
    const li = document.createElement('li');
    li.className = 'task';

    const textSpan = document.createElement('span');
    textSpan.id = `todo-text-${task.id}`;
    textSpan.className = 'todo-text' + (task.done ? ' done' : '');
    textSpan.textContent = task.text;

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.id = `todo-check-${task.id}`;
    checkbox.checked = task.done;
    checkbox.setAttribute('aria-label', `Mark task ${task.text} as done`);
    checkbox.addEventListener('change', () => {
      task.done = checkbox.checked;
      textSpan.classList.toggle('done', task.done);
      updateCounts();
    });

    const deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.id = `todo-delete-${task.id}`;
    deleteBtn.textContent = 'Delete';
    deleteBtn.setAttribute('aria-label', `Delete task ${task.text}`);
    deleteBtn.addEventListener('click', () => {
      const index = tasks.indexOf(task);
      if (index !== -1) tasks.splice(index, 1);
      li.remove();
      updateCounts();
    });

    li.append(checkbox, textSpan, deleteBtn);
    listEl.appendChild(li);
  };

  const addTask = () => {
    const text = input.value.trim();
    if (!text) {
      input.value = '';
      return;
    }
    const task = { id: nextId++, text, done: false };
    tasks.push(task);
    renderTask(task);
    input.value = '';
    input.focus();
    updateCounts();
  };

  addBtn.addEventListener('click', addTask);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addTask();
    }
  });

  updateCounts();
})();