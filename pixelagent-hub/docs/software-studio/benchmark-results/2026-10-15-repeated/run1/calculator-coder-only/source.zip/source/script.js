'use strict';

const leftInput = document.getElementById('left');
const rightInput = document.getElementById('right');
const operationSelect = document.getElementById('operation');
const calculateButton = document.getElementById('calculate');
const resultOutput = document.getElementById('result');

function readNumber(input) {
  if (input.value.trim() === '') return null;
  const number = Number(input.value);
  return Number.isFinite(number) ? number : null;
}

function setError() {
  resultOutput.textContent = 'Error';
}

calculateButton.addEventListener('click', () => {
  const left = readNumber(leftInput);
  const right = readNumber(rightInput);

  if (left === null || right === null) {
    setError();
    return;
  }

  let result;
  switch (operationSelect.value) {
    case 'add':
      result = left + right;
      break;
    case 'subtract':
      result = left - right;
      break;
    case 'multiply':
      result = left * right;
      break;
    case 'divide':
      if (right === 0) {
        setError();
        return;
      }
      result = left / right;
      break;
    default:
      setError();
      return;
  }

  if (!Number.isFinite(result)) {
    setError();
    return;
  }

  resultOutput.textContent = String(result);
});
