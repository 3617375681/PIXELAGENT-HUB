# Pixel Two-Number Calculator

A tiny offline calculator with a retro pixel look. It accepts two numeric inputs, applies an operation, and shows only the numeric result.

## How to run
Open `index.html` in any modern browser. No build tools or network access needed.

## Features
- Supports negative and decimal inputs
- Add, subtract, multiply, divide
- Division by zero, empty inputs, and non-finite numbers display `Error`
- Pixel-style UI and keyboard-accessible controls

## Files
- `index.html` - structure and labeled controls
- `style.css` - pixel styling
- `script.js` - calculation logic
