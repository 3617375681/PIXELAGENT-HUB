const count = document.getElementById('count');
const increase = document.getElementById('increase');
const decrease = document.getElementById('decrease');
const reset = document.getElementById('reset');

let value = 0;

function update() {
  count.textContent = value;
}

increase.addEventListener('click', () => {
  value += 1;
  update();
});

decrease.addEventListener('click', () => {
  value -= 1;
  update();
});

reset.addEventListener('click', () => {
  value = 0;
  update();
});

update();