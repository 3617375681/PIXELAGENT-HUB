# Pixel Counter

An offline pixel-style counter built with HTML, CSS, and vanilla JavaScript.

## Run
Open `index.html` in a browser. No build step or dependencies required.

## Controls
- **Increase** (`#increase`) adds 1
- **Decrease** (`#decrease`) subtracts 1
- **Reset** (`#reset`) sets the count to 0
- The current integer is shown in `<output id="count">`

## Features
- Initial value is 0
- Supports negative numbers
- Keyboard-accessible buttons (tab to focus, Enter/Space to press)
- No storage, network requests, or external assets