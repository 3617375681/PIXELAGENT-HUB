# Pixel Counter

A dependency-free, offline, pixel-style counter with accessible keyboard controls.

## Usage
Open `index.html` in any modern web browser. The count starts at `0`.

- Press **Increase** (`+1`) to add one.
- Press **Decrease** (`-1`) to subtract one. The count can go below zero.
- Press **Reset** (`0`) to set the count back to zero.

## Keyboard Controls
Use `Tab` to move between buttons. Press `Enter` or `Space` on a focused button to activate it.

## Files
- `index.html` - semantic structure and accessible controls
- `styles.css` - pixel-style visual design
- `script.js` - counter logic using `addEventListener`

## Accessibility
Buttons are native `<button>` elements with `aria-label`s. The count output uses `aria-live='polite'` to announce changes to screen readers.

## Implementation Notes
No external dependencies, network requests, storage, or inline event handlers are used. Total source is under 200 lines.