(function () {
  'use strict';
  let value = 0;
  const count = document.getElementById('count');
  const increase = document.getElementById('increase');
  const decrease = document.getElementById('decrease');
  const reset = document.getElementById('reset');

  function update() {
    count.textContent = String(value);
  }

  increase.addEventListener('click', function () {
    value += 1;
    update();
  });

  decrease.addEventListener('click', function () {
    value -= 1;
    update();
  });

  reset.addEventListener('click', function () {
    value = 0;
    update();
  });

  update();
})();