# Pixel Two-Number Calculator

A simple offline pixel-style calculator built with plain HTML, CSS, and JavaScript.

## Features
- Takes two numeric inputs (supports negative and decimal numbers)
- Operation: add, subtract, multiply, divide
- Outputs only the numeric result or exact text "Error" for invalid input or division by zero
- Keyboard-accessible labeled controls
- No external dependencies, works fully offline

## Files
- `index.html` – structure and controls
- `styles.css` – pixel-art styling
- `script.js` – calculator logic and validation

## Usage
Open `index.html` in any modern web browser. Enter numbers, choose an operation, and click Calculate or press Enter (if button focused). The result appears in the output area.

## Validation Rules
- Empty or whitespace-only inputs: Error
- Non-numeric or non-finite values: Error
- Division by zero: Error