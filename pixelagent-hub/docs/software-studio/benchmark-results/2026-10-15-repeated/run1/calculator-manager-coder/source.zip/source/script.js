const leftInput = document.getElementById('left');
const rightInput = document.getElementById('right');
const operationSelect = document.getElementById('operation');
const calculateButton = document.getElementById('calculate');
const resultOutput = document.getElementById('result');

function calculate() {
  const leftRaw = leftInput.value.trim();
  const rightRaw = rightInput.value.trim();
  const operation = operationSelect.value;

  // Reject empty inputs
  if (leftRaw === '' || rightRaw === '') {
    resultOutput.textContent = 'Error';
    return;
  }

  const left = Number(leftRaw);
  const right = Number(rightRaw);

  // Reject non-finite numbers
  if (!Number.isFinite(left) || !Number.isFinite(right)) {
    resultOutput.textContent = 'Error';
    return;
  }

  let result;
  switch (operation) {
    case 'add':
      result = left + right;
      break;
    case 'subtract':
      result = left - right;
      break;
    case 'multiply':
      result = left * right;
      break;
    case 'divide':
      if (right === 0) {
        resultOutput.textContent = 'Error';
        return;
      }
      result = left / right;
      break;
    default:
      resultOutput.textContent = 'Error';
      return;
  }

  resultOutput.textContent = String(result);
}

calculateButton.addEventListener('click', calculate);

// Initialize result to 0
resultOutput.textContent = '0';