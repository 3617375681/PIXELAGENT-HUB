# Pixel Temperature Converter

An offline HTML/CSS/JS app that converts temperatures with a retro pixel look.

## Usage
1. Open `index.html` in any modern browser.
2. Enter a numeric temperature.
3. Choose conversion direction.
4. Click **Convert** or press Enter.

## Formulas
- Celsius to Fahrenheit: `x * 9 / 5 + 32`
- Fahrenheit to Celsius: `(x - 32) * 5 / 9`

## Validation
- Empty, non-numeric, or non-finite input shows `Error`.
- Valid results use exactly two decimal places.