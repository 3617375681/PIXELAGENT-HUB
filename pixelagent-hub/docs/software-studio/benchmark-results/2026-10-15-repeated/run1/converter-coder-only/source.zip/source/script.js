const tempInput = document.getElementById('temperature');
const direction = document.getElementById('direction');
const convertBtn = document.getElementById('convert');
const result = document.getElementById('result');

function convertTemperature(raw, selectedDirection) {
  if (raw.trim() === '') return 'Error';
  const value = Number(raw);
  if (!Number.isFinite(value)) return 'Error';
  const converted = selectedDirection === 'c-to-f'
    ? (value * 9) / 5 + 32
    : ((value - 32) * 5) / 9;
  return converted.toFixed(2);
}

convertBtn.addEventListener('click', () => {
  result.textContent = convertTemperature(tempInput.value, direction.value);
});

[tempInput, direction].forEach((element) => {
  element.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      convertBtn.click();
    }
  });
});