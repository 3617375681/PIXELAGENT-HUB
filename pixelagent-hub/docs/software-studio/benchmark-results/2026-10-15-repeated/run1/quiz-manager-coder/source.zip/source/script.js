(function() {
  'use strict';

  const questionEl = document.getElementById('question');
  const answerA = document.getElementById('answer-a');
  const answerB = document.getElementById('answer-b');
  const scoreEl = document.getElementById('score');
  const nextBtn = document.getElementById('next');
  const restartBtn = document.getElementById('restart');

  const questions = [
    { text: '2 + 2 = ?', a: '4', b: '5', correct: 'a' },
    { text: '3 + 3 = ?', a: '5', b: '6', correct: 'b' }
  ];

  let currentIndex = 0;
  let score = 0;
  let answered = false;

  function updateQuestion() {
    const q = questions[currentIndex];
    questionEl.textContent = q.text;
    answerA.textContent = q.a;
    answerB.textContent = q.b;
    answered = false;
    answerA.disabled = false;
    answerB.disabled = false;
  }

  function lockAnswers() {
    answered = true;
    answerA.disabled = true;
    answerB.disabled = true;
  }

  function handleAnswer(e) {
    if (answered) return;
    const id = e.target.id;
    const q = questions[currentIndex];
    lockAnswers();
    if (id === q.correct) {
      score += 1;
      scoreEl.textContent = score;
    }
  }

  function handleNext() {
    if (currentIndex === 0) {
      currentIndex = 1;
      updateQuestion();
    } else if (currentIndex === 1) {
      questionEl.textContent = 'Finished';
      answerA.disabled = true;
      answerB.disabled = true;
      nextBtn.disabled = true;
    }
  }

  function handleRestart() {
    currentIndex = 0;
    score = 0;
    scoreEl.textContent = score;
    updateQuestion();
    nextBtn.disabled = false;
  }

  answerA.addEventListener('click', handleAnswer);
  answerB.addEventListener('click', handleAnswer);
  nextBtn.addEventListener('click', handleNext);
  restartBtn.addEventListener('click', handleRestart);

  handleRestart();
})();