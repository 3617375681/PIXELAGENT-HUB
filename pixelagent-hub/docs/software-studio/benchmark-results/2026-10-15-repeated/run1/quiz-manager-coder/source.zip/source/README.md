# Pixel Two-Question Quiz

A small offline quiz built with HTML, CSS, and plain JavaScript.

## How to Run
1. Download or clone the files into a folder.
2. Open `index.html` in any modern browser. No server or internet required.

## Controls
- **Answer A / Answer B**: click to answer the current question.
- **Next**: advance to the next question or finish the quiz.
- **Restart**: reset the quiz to the first question and score 0.

## Behavior
- Question 1: `2 + 2 = ?` (A: 4, B: 5)
- Question 2: `3 + 3 = ?` (A: 5, B: 6)
- Score increments once per question only on the correct answer.
- After answering the second question and clicking Next, the question area shows `Finished`.

## Accessibility
- All buttons have accessible labels and focus indicators.
- Live regions announce question and score changes.