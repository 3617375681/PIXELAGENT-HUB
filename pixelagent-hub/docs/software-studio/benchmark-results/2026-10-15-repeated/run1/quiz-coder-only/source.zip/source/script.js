const question = document.getElementById('question');
const answerA = document.getElementById('answer-a');
const answerB = document.getElementById('answer-b');
const nextButton = document.getElementById('next');
const restartButton = document.getElementById('restart');
const scoreOutput = document.getElementById('score');

const questions = [
  { text: '2 + 2 = ?', a: '4', b: '5', correct: '4' },
  { text: '3 + 3 = ?', a: '5', b: '6', correct: '6' }
];

const state = { current: 0, score: 0, answered: false };

function render() {
  const q = questions[state.current];
  if (!q) {
    question.textContent = 'Finished';
    answerA.disabled = true;
    answerB.disabled = true;
    nextButton.disabled = true;
    scoreOutput.textContent = state.score;
    return;
  }

  question.textContent = q.text;
  answerA.textContent = q.a;
  answerB.textContent = q.b;
  answerA.disabled = state.answered;
  answerB.disabled = state.answered;
  nextButton.disabled = !state.answered;
  scoreOutput.textContent = state.score;
}

function chooseAnswer(value) {
  if (state.answered || !questions[state.current]) {
    return;
  }
  state.answered = true;
  if (value === questions[state.current].correct) {
    state.score += 1;
  }
  render();
}

answerA.addEventListener('click', function () {
  chooseAnswer(answerA.textContent);
});

answerB.addEventListener('click', function () {
  chooseAnswer(answerB.textContent);
});

nextButton.addEventListener('click', function () {
  if (!state.answered || !questions[state.current]) {
    return;
  }
  state.current += 1;
  state.answered = false;
  render();
});

restartButton.addEventListener('click', function () {
  state.current = 0;
  state.score = 0;
  state.answered = false;
  render();
});

render();