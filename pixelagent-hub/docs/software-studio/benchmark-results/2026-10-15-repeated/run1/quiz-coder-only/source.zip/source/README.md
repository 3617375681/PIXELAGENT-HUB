# Pixel Quiz

An offline two-question quiz in a pixel style, using only HTML, CSS, and JavaScript.

## Run

Open `index.html` in any modern browser. No server, packages, or network required.

## Controls

- Click an answer to lock it in. Correct answers add 1 to the score.
- `Next` advances to the next question after you answer.
- `Restart` resets the quiz to the first question and score 0.

## Structure

- `index.html` — page markup
- `style.css` — pixel visual styling
- `script.js` — quiz logic