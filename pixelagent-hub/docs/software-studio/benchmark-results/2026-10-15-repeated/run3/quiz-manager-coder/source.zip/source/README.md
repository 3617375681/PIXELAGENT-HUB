# Offline Pixel Quiz

A two-question arithmetic quiz with retro pixel styling. Runs entirely offline in a browser.

## Run

Open `index.html` in any modern browser. No build step or server required.

## Features

- First question: `2 + 2 = ?` with answers 4 and 5.
- Second question: `3 + 3 = ?` with answers 5 and 6.
- Score starts at 0 and increments once per correct answer.
- Answers lock after selecting.
- Next advances to the second question, then to Finished.
- Restart resets the quiz and score.

## Controls

- Click or tab to `4` / `5` on the first question, then `5` / `6` on the second.
- Use `Next` to continue after answering.
- Use `Restart` to reset.
