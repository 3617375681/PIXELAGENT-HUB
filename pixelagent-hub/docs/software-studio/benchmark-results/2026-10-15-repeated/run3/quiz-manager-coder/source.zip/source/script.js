const questions = [
  { text: '2 + 2 = ?', answers: ['4', '5'], correct: 'a' },
  { text: '3 + 3 = ?', answers: ['5', '6'], correct: 'b' }
];

let current = 0;
let score = 0;
let answered = false;

const questionEl = document.getElementById('question');
const answerA = document.getElementById('answer-a');
const answerB = document.getElementById('answer-b');
const nextBtn = document.getElementById('next');
const restartBtn = document.getElementById('restart');
const scoreEl = document.getElementById('score');

function setQuestion(index) {
  const q = questions[index];
  questionEl.textContent = q.text;
  answerA.textContent = q.answers[0];
  answerB.textContent = q.answers[1];
  answerA.disabled = false;
  answerB.disabled = false;
  answered = false;
  nextBtn.disabled = true;
}

function answer(choice) {
  if (answered) return;
  answered = true;
  answerA.disabled = true;
  answerB.disabled = true;
  if (choice === questions[current].correct) {
    score += 1;
    scoreEl.textContent = score;
  }
  nextBtn.disabled = false;
}

function finish() {
  questionEl.textContent = 'Finished';
  answerA.disabled = true;
  answerB.disabled = true;
  nextBtn.disabled = true;
}

function next() {
  if (!answered) return;
  if (current === 0) {
    current = 1;
    setQuestion(current);
  } else if (current === 1) {
    finish();
    current = 2;
  }
}

function restart() {
  current = 0;
  score = 0;
  scoreEl.textContent = score;
  setQuestion(current);
}

answerA.addEventListener('click', () => answer('a'));
answerB.addEventListener('click', () => answer('b'));
nextBtn.addEventListener('click', next);
restartBtn.addEventListener('click', restart);

setQuestion(0);
