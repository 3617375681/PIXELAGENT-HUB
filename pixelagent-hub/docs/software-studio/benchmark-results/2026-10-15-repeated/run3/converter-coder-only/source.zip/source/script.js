const form = document.getElementById('converter');
const temperature = document.getElementById('temperature');
const direction = document.getElementById('direction');
const result = document.getElementById('result');

form.addEventListener('submit', (event) => {
  event.preventDefault();

  const raw = temperature.value.trim();
  const value = Number(raw);

  if (raw === '' || !Number.isFinite(value)) {
    result.textContent = 'Error';
    return;
  }

  const converted = direction.value === 'c-to-f'
    ? value * 9 / 5 + 32
    : (value - 32) * 5 / 9;

  result.textContent = converted.toFixed(2);
});
