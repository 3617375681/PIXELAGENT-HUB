# Pixel Temperature Converter

A tiny offline converter built with plain HTML, CSS, and JavaScript.

## Files
- index.html - page structure and labels
- style.css - pixel-style layout
- script.js - conversion logic

## Usage
Open `index.html` in any modern browser. Enter a temperature, choose a conversion direction, and press Convert or Enter.

## Rules
- `°F = °C × 9/5 + 32`
- `°C = (°F − 32) × 5/9`
- Result is shown with exactly two decimal places and no unit.
- Empty or invalid input shows `Error`.
- No external assets, packages, storage, or network usage.
