# Pixel Quiz

An offline, pixel-style two-question quiz built with plain HTML, CSS, and JavaScript.

## How to Run

Open `index.html` in any modern browser. No build tools, packages, network access, or storage are required.

## How to Play

1. Read the question.
2. Click one of the two answer buttons. Your answer is locked and score updates if correct.
3. Click **Next** to continue to the next question.
4. After the second question, click **Next** to show **Finished**.
5. Click **Restart** to reset to the first question with a score of 0.

All buttons are keyboard accessible by tabbing and pressing Enter or Space.