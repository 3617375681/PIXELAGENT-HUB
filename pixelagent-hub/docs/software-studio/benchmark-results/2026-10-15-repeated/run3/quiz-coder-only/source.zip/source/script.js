const qEl = document.getElementById('question');
const aBtn = document.getElementById('answer-a');
const bBtn = document.getElementById('answer-b');
const scoreEl = document.getElementById('score');
const nextBtn = document.getElementById('next');
const restartBtn = document.getElementById('restart');

const questions = [
  { text: '2 + 2 = ?', answers: ['4', '5'], correct: 0 },
  { text: '3 + 3 = ?', answers: ['5', '6'], correct: 1 }
];

let current = 0;
let score = 0;
let answered = false;

function updateQuestion() {
  if (current < questions.length) {
    const q = questions[current];
    qEl.textContent = q.text;
    aBtn.textContent = q.answers[0];
    bBtn.textContent = q.answers[1];
    aBtn.disabled = false;
    bBtn.disabled = false;
    nextBtn.disabled = !answered;
  } else {
    qEl.textContent = 'Finished';
    aBtn.disabled = true;
    bBtn.disabled = true;
    nextBtn.disabled = true;
  }
}

function handleAnswer(index) {
  if (answered || current >= questions.length) return;
  answered = true;
  aBtn.disabled = true;
  bBtn.disabled = true;
  if (questions[current].correct === index) {
    score += 1;
    scoreEl.textContent = score;
  }
  nextBtn.disabled = false;
}

aBtn.addEventListener('click', () => handleAnswer(0));
bBtn.addEventListener('click', () => handleAnswer(1));

nextBtn.addEventListener('click', () => {
  if (!answered || current >= questions.length) return;
  current += 1;
  answered = false;
  if (current < questions.length) {
    nextBtn.disabled = true;
  }
  updateQuestion();
});

restartBtn.addEventListener('click', () => {
  current = 0;
  score = 0;
  answered = false;
  scoreEl.textContent = score;
  updateQuestion();
});

updateQuestion();