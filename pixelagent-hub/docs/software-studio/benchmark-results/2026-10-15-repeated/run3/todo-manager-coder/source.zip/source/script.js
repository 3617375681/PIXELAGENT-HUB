const input = document.getElementById('todo-input');
const list = document.getElementById('todo-list');
const totalSpan = document.getElementById('todo-total');
const remainingSpan = document.getElementById('remaining');

let tasks = [];
let nextId = 1;

function render() {
  list.innerHTML = '';
  let remaining = 0;
  for (const task of tasks) {
    if (!task.done) remaining++;
    const li = document.createElement('li');
    li.className = 'task-row' + (task.done ? ' done' : '');
    const label = document.createElement('label');
    label.className = 'task-label';
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.id = 'todo-check-' + task.id;
    checkbox.checked = task.done;
    checkbox.addEventListener('change', () => toggleTask(task.id));
    const span = document.createElement('span');
    span.id = 'todo-text-' + task.id;
    span.textContent = task.text;
    label.append(checkbox, span);
    const del = document.createElement('button');
    del.type = 'button';
    del.id = 'todo-delete-' + task.id;
    del.className = 'delete-btn';
    del.textContent = 'Delete';
    del.setAttribute('aria-label', 'Delete ' + task.text);
    del.addEventListener('click', () => deleteTask(task.id));
    li.append(label, del);
    list.appendChild(li);
  }
  totalSpan.textContent = tasks.length;
  remainingSpan.textContent = remaining;
}

function addTask(text) {
  const trimmed = text.trim();
  if (trimmed === '') return;
  tasks.push({ id: nextId++, text: trimmed, done: false });
  render();
}

function toggleTask(id) {
  const task = tasks.find(t => t.id === id);
  if (task) {
    task.done = !task.done;
    render();
  }
}

function deleteTask(id) {
  tasks = tasks.filter(t => t.id !== id);
  render();
}

document.getElementById('task-form').addEventListener('submit', (e) => {
  e.preventDefault();
  addTask(input.value);
  input.value = '';
  input.focus();
});

render();