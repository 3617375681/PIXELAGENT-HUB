# Offline Pixel Task List

A tiny offline task list built with HTML, CSS, and vanilla JavaScript. It uses a pixel-style interface and stores all task state in memory.

## Usage

Open `index.html` in any modern browser. No server or build step needed.

1. Type a task into the labeled input.
2. Press Enter or click **Add**.
3. Check the checkbox to mark a task complete; the incomplete count updates.
4. Click **Delete** to remove a task; both counts update.

Blank input is ignored.

## Files

- `index.html` - accessible page structure and required IDs.
- `styles.css` - pixel-art styling, layout, and visible focus states.
- `script.js` - in-memory task state, rendering, and event handling.

## Notes

All data is kept in memory only. Refreshing the page resets the list.