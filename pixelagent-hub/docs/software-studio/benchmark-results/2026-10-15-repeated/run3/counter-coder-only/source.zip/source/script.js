let count = 0;

const output = document.getElementById('count');
const increase = document.getElementById('increase');
const decrease = document.getElementById('decrease');
const reset = document.getElementById('reset');

function updateDisplay() {
  output.textContent = count;
}

increase.addEventListener('click', () => {
  count += 1;
  updateDisplay();
});

decrease.addEventListener('click', () => {
  count -= 1;
  updateDisplay();
});

reset.addEventListener('click', () => {
  count = 0;
  updateDisplay();
});
