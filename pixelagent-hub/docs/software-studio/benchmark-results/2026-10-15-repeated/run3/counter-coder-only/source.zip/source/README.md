# Pixel Counter

An offline pixel-style counter app with no dependencies or storage.

## Features

- Starts at 0.
- Increase by 1 with the **+1** button.
- Decrease by 1 with the **-1** button, including negative numbers.
- Reset to 0 with the **RESET** button.
- Keyboard-accessible native buttons.

## Usage

Open `index.html` in any modern browser.
