# Pixel Tasks

A tiny offline, pixel-style task list built with plain HTML, CSS, and JavaScript.

## How to run
Open `index.html` in any modern browser. No server or internet connection is required.

## Features
- Add tasks with the input and **Add** button (or press Enter).
- Each task has a checkbox to mark it complete and a Delete button.
- Counts show total tasks and incomplete (remaining) tasks.
- Blank input is ignored, and task text is trimmed.
- All data is kept in memory; refreshing clears the list.