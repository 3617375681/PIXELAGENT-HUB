(() => {
  const input = document.getElementById('todo-input');
  const addBtn = document.getElementById('todo-add');
  const list = document.getElementById('todo-list');
  const totalEl = document.getElementById('todo-total');
  const remainingEl = document.getElementById('remaining');
  const tasks = [];
  let nextId = 1;

  const updateCounts = () => {
    totalEl.textContent = String(tasks.length);
    remainingEl.textContent = String(tasks.filter(task => !task.completed).length);
  };

  const renderTask = (task) => {
    const li = document.createElement('li');
    li.dataset.id = String(task.id);
    if (task.completed) li.classList.add('completed');

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.id = `todo-check-${task.id}`;
    checkbox.checked = task.completed;
    checkbox.addEventListener('change', () => {
      task.completed = checkbox.checked;
      li.classList.toggle('completed', task.completed);
      updateCounts();
    });

    const label = document.createElement('label');
    label.htmlFor = checkbox.id;
    label.className = 'task-text';
    const span = document.createElement('span');
    span.id = `todo-text-${task.id}`;
    span.textContent = task.text;
    label.appendChild(span);

    const deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.id = `todo-delete-${task.id}`;
    deleteBtn.textContent = 'Delete';
    deleteBtn.setAttribute('aria-label', `Delete ${task.text}`);
    deleteBtn.addEventListener('click', () => {
      const index = tasks.findIndex(t => t.id === task.id);
      if (index !== -1) tasks.splice(index, 1);
      li.remove();
      updateCounts();
    });

    li.append(checkbox, label, deleteBtn);
    list.appendChild(li);
  };

  const addTask = () => {
    const text = input.value.trim();
    if (!text) return;
    const task = { id: nextId, text, completed: false };
    tasks.push(task);
    nextId += 1;
    renderTask(task);
    input.value = '';
    updateCounts();
    input.focus();
  };

  addBtn.addEventListener('click', addTask);
  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      addTask();
    }
  });

  updateCounts();
})();