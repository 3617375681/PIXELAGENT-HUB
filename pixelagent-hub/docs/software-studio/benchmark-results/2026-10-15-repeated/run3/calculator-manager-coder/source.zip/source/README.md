# Pixel Two-Number Calculator

A tiny offline calculator with a pixel-art style built with plain HTML, CSS, and JavaScript.

## How to Run

Open `index.html` in any modern web browser. No build step, packages, or internet connection is required.

## Usage

1. Enter a left number (negative values allowed, e.g. `-2.5`).
2. Enter a right number.
3. Choose an operation: Add, Subtract, Multiply, or Divide.
4. Click `Calculate` or press Enter.
5. The result area shows only the numeric result, or `Error` for invalid input or division by zero.

## Files

- `index.html` — page structure.
- `styles.css` — pixel-style layout and focus states.
- `script.js` — calculation and validation logic.

## Notes

- Empty or non-finite numbers are rejected with exact text `Error`.
- Division by zero is rejected with exact text `Error`.
- Output initially displays `0`.