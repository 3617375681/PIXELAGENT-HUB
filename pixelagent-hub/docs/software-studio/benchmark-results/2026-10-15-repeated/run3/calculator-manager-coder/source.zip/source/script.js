const $ = (id) => document.getElementById(id);

function calculate() {
  const left = $('left').value.trim();
  const right = $('right').value.trim();
  const out = $('result');

  if (left === '' || right === '') {
    out.textContent = 'Error';
    return;
  }

  const a = Number(left);
  const b = Number(right);

  if (!Number.isFinite(a) || !Number.isFinite(b)) {
    out.textContent = 'Error';
    return;
  }

  const op = $('operation').value;

  if (op === 'divide' && b === 0) {
    out.textContent = 'Error';
    return;
  }

  let answer;
  switch (op) {
    case 'add': answer = a + b; break;
    case 'subtract': answer = a - b; break;
    case 'multiply': answer = a * b; break;
    case 'divide': answer = a / b; break;
    default: out.textContent = 'Error'; return;
  }
  out.textContent = String(answer);
}

$('calculate').addEventListener('click', calculate);

document.addEventListener('keydown', (event) => {
  if (event.key === 'Enter' && event.target.tagName !== 'BUTTON') {
    calculate();
  }
});