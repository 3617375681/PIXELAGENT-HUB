# Pixel Temperature Converter

An offline, pixel-style temperature converter built with plain HTML, CSS, and JavaScript.

## Usage
1. Open `index.html` in any modern browser.
2. Enter a temperature number.
3. Choose the conversion direction.
4. Click **Convert** or press **Enter**.
5. The result appears with exactly two decimal places. Empty or invalid input shows `Error`.

## Formulas
- C to F: `x * 9 / 5 + 32`
- F to C: `(x - 32) * 5 / 9`

## Files
- `index.html`: page structure, labels, and visible formulas
- `styles.css`: pixel/retro visual theme
- `script.js`: conversion logic and event handling

## Notes
- No dependencies, packages, network requests, or browser storage.
- Works fully offline.
- Keyboard accessible with labeled controls and visible focus states.