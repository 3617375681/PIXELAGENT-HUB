const leftInput = document.getElementById('left');
const rightInput = document.getElementById('right');
const operationSelect = document.getElementById('operation');
const calculateButton = document.getElementById('calculate');
const resultOutput = document.getElementById('result');

function calculate() {
  const a = leftInput.valueAsNumber;
  const b = rightInput.valueAsNumber;

  if (!Number.isFinite(a) || !Number.isFinite(b)) {
    resultOutput.textContent = 'Error';
    return;
  }

  let answer;

  switch (operationSelect.value) {
    case 'add':
      answer = a + b;
      break;
    case 'subtract':
      answer = a - b;
      break;
    case 'multiply':
      answer = a * b;
      break;
    case 'divide':
      if (b === 0) {
        resultOutput.textContent = 'Error';
        return;
      }
      answer = a / b;
      break;
    default:
      resultOutput.textContent = 'Error';
      return;
  }

  if (!Number.isFinite(answer)) {
    resultOutput.textContent = 'Error';
    return;
  }

  resultOutput.textContent = String(answer);
}

calculateButton.addEventListener('click', calculate);

[leftInput, rightInput, operationSelect].forEach((control) => {
  control.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      calculate();
    }
  });
});