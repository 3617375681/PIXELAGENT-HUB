# Pixel Two-Number Calculator

An offline pixel-style calculator built with plain HTML, CSS, and JavaScript.

## Files

- `index.html` — semantic structure and labeled controls.
- `styles.css` — pixel-art UI, focus states, and layout.
- `script.js` — calculation and validation logic.

## Usage

1. Open `index.html` in any modern browser.
2. Enter left and right numbers, including negative or decimal values.
3. Choose an operation.
4. Click **Calculate** or press Enter while focused on a control.

## Behavior

- Initial result is `0`.
- Empty or non-finite inputs show exactly `Error`.
- Division by zero shows exactly `Error`.
- Result shows only the number, or `Error` for invalid input.

## Accessibility

- All inputs, select, and button have visible labels.
- Focus styling is provided.
- Enter key triggers calculation from inputs and select.