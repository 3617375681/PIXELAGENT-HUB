# Pixel Counter

An offline, pixel-style counter built with plain HTML, CSS, and JavaScript.

## Features
- Starts at 0
- Increase by one
- Decrease by one (supports negative numbers)
- Reset to zero
- Pixel-style visuals
- Keyboard-accessible buttons

## Files
- index.html - semantic counter structure
- styles.css - pixel-style appearance and focus states
- app.js - counter logic using addEventListener

## Usage
Open index.html in any modern browser. Use the buttons or tab to a button and press Enter or Space.

No dependencies, no network requests, no storage.