let count = 0;
const output = document.getElementById('count');

function updateDisplay() {
  output.textContent = count;
}

document.getElementById('increase').addEventListener('click', () => {
  count += 1;
  updateDisplay();
});

document.getElementById('decrease').addEventListener('click', () => {
  count -= 1;
  updateDisplay();
});

document.getElementById('reset').addEventListener('click', () => {
  count = 0;
  updateDisplay();
});

updateDisplay();