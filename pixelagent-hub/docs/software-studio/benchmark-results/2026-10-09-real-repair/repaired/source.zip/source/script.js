(function () {
  if (window.__pixelCounterInitialized) return;
  window.__pixelCounterInitialized = true;

  const countEl = document.getElementById('count');
  let count = 0;

  function update() {
    countEl.textContent = count;
  }

  document.getElementById('increase').addEventListener('click', function () {
    count += 1;
    update();
  });

  document.getElementById('decrease').addEventListener('click', function () {
    count -= 1;
    update();
  });

  document.getElementById('reset').addEventListener('click', function () {
    count = 0;
    update();
  });

  update();
})();