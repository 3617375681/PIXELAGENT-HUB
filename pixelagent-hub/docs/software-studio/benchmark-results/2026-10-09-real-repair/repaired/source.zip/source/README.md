# Pixel Counter

An offline pixel-style counter built with plain HTML, CSS, and JavaScript. It starts at `0` and supports negative integers.

## Run

Open `index.html` in any modern browser. No network, dependencies, or build steps are needed.

## Controls

- **Increase +1** — adds one to the count
- **Decrease -1** — subtracts one from the count
- **Reset to 0** — resets the count to zero

The controls are native buttons, so they are keyboard accessible: use `Tab` to focus and `Enter` or `Space` to activate.

## Files

- `index.html` — semantic structure and labeled buttons
- `styles.css` — pixel-style appearance and focus states
- `script.js` — counter logic with `addEventListener`

## Notes

- Output `#count` shows only the integer value.
- No storage, external assets, or imports are used.