(() => {
  'use strict';

  const canvas = document.getElementById('gameCanvas');
  const ctx = canvas.getContext('2d');
  const scoreEl = document.getElementById('score');
  const overlay = document.getElementById('overlay');
  const overlayTitle = document.getElementById('overlayTitle');
  const overlayText = document.getElementById('overlayText');
  const startBtn = document.getElementById('startBtn');
  const pauseBtn = document.getElementById('pauseBtn');
  const restartBtn = document.getElementById('restartBtn');

  const COLS = 20;
  const ROWS = 20;
  const CELL = 20;
  const STEP_MS = 150;

  let snake;
  let food;
  let direction;
  let nextDirection;
  let score;
  let state;
  let lastTime = 0;
  let accumulator = 0;

  function resetGame() {
    snake = [
      { x: 8, y: 10 },
      { x: 7, y: 10 },
      { x: 6, y: 10 },
    ];
    direction = { x: 1, y: 0 };
    nextDirection = { x: 1, y: 0 };
    score = 0;
    scoreEl.textContent = '0';
    food = createFood();
  }

  function createFood() {
    let pos;
    do {
      pos = {
        x: Math.floor(Math.random() * COLS),
        y: Math.floor(Math.random() * ROWS),
      };
    } while (snake.some(segment => segment.x === pos.x && segment.y === pos.y));
    return pos;
  }

  function update() {
    direction = { ...nextDirection };
    const head = snake[0];
    const newHead = {
      x: head.x + direction.x,
      y: head.y + direction.y,
    };

    if (newHead.x < 0 || newHead.x >= COLS || newHead.y < 0 || newHead.y >= ROWS) {
      gameOver();
      return;
    }

    const willEat = newHead.x === food.x && newHead.y === food.y;
    const bodyToCheck = willEat ? snake : snake.slice(0, -1);

    if (bodyToCheck.some(segment => segment.x === newHead.x && segment.y === newHead.y)) {
      gameOver();
      return;
    }

    snake.unshift(newHead);
    if (willEat) {
      score += 10;
      scoreEl.textContent = String(score);
      food = createFood();
    } else {
      snake.pop();
    }
  }

  function gameOver() {
    state = 'gameover';
    showOverlay('Game Over', `Your score: ${score}`);
    startBtn.textContent = 'Play Again';
    pauseBtn.disabled = true;
    pauseBtn.textContent = 'Pause';
  }

  function startGame() {
    if (state === 'gameover') {
      resetGame();
    }
    state = 'running';
    hideOverlay();
    pauseBtn.disabled = false;
    pauseBtn.textContent = 'Pause';
    lastTime = performance.now();
    accumulator = 0;
  }

  function togglePause() {
    if (state === 'running') {
      state = 'paused';
      showOverlay('Paused', 'Press Space or click Resume to continue.');
      startBtn.textContent = 'Resume';
      pauseBtn.textContent = 'Resume';
    } else if (state === 'paused') {
      state = 'running';
      hideOverlay();
      pauseBtn.textContent = 'Pause';
      lastTime = performance.now();
      accumulator = 0;
    }
  }

  function restartGame() {
    resetGame();
    state = 'running';
    hideOverlay();
    pauseBtn.disabled = false;
    pauseBtn.textContent = 'Pause';
    lastTime = performance.now();
    accumulator = 0;
  }

  function showOverlay(title, text) {
    overlayTitle.textContent = title;
    overlayText.textContent = text;
    overlay.classList.remove('hidden');
  }

  function hideOverlay() {
    overlay.classList.add('hidden');
  }

  function changeDirection(x, y) {
    if (state !== 'running' && state !== 'paused') return;
    if (direction.x === -x && direction.y === -y) return;
    nextDirection = { x, y };
  }

  function handleSpaceOrP() {
    if (state === 'running' || state === 'paused') {
      togglePause();
    } else if (state === 'ready') {
      startGame();
    } else if (state === 'gameover') {
      startGame();
    }
  }

  function handleKeydown(event) {
    const key = event.key;

    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(key)) {
      event.preventDefault();
      if (key === 'ArrowUp') changeDirection(0, -1);
      if (key === 'ArrowDown') changeDirection(0, 1);
      if (key === 'ArrowLeft') changeDirection(-1, 0);
      if (key === 'ArrowRight') changeDirection(1, 0);
      return;
    }

    if (key === ' ' || key === 'Spacebar' || key === 'p' || key === 'P') {
      const activeTag = document.activeElement?.tagName;
      if (key === ' ' || key === 'Spacebar') {
        if (activeTag !== 'BUTTON') {
          event.preventDefault();
          handleSpaceOrP();
        }
      } else {
        event.preventDefault();
        handleSpaceOrP();
      }
      return;
    }

    if (key === 'r' || key === 'R') {
      event.preventDefault();
      restartGame();
    }
  }

  function draw() {
    ctx.fillStyle = '#22243a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = 'rgba(255,255,255,0.04)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= COLS; i++) {
      ctx.beginPath();
      ctx.moveTo(i * CELL, 0);
      ctx.lineTo(i * CELL, canvas.height);
      ctx.stroke();
    }
    for (let i = 0; i <= ROWS; i++) {
      ctx.beginPath();
      ctx.moveTo(0, i * CELL);
      ctx.lineTo(canvas.width, i * CELL);
      ctx.stroke();
    }

    ctx.fillStyle = '#f87171';
    ctx.fillRect(food.x * CELL + 2, food.y * CELL + 2, CELL - 4, CELL - 4);

    snake.forEach((segment, index) => {
      ctx.fillStyle = index === 0 ? '#6ee7b7' : '#4ade80';
      ctx.fillRect(segment.x * CELL + 1, segment.y * CELL + 1, CELL - 2, CELL - 2);
    });
  }

  function loop(time) {
    if (state === 'running') {
      accumulator += time - lastTime;
      if (accumulator >= STEP_MS) {
        accumulator -= STEP_MS;
        update();
      }
    }
    lastTime = time;
    draw();
    requestAnimationFrame(loop);
  }

  startBtn.addEventListener('click', startGame);
  pauseBtn.addEventListener('click', togglePause);
  restartBtn.addEventListener('click', restartGame);
  document.addEventListener('keydown', handleKeydown);

  resetGame();
  state = 'ready';
  pauseBtn.disabled = true;
  pauseBtn.textContent = 'Pause';
  showOverlay('How to Play', 'Use the arrow keys to move the snake. Eat the red food to grow and earn points. Avoid walls and your own tail.');
  startBtn.textContent = 'Start Game';
  lastTime = performance.now();
  requestAnimationFrame(loop);
})();
