# Pixel Snake Game

An offline browser-based snake game built with plain HTML, CSS, and JavaScript. No packages or network access are needed.

## Run

Open `index.html` in any modern browser.

## Controls

- Arrow keys: move the snake
- Space or P: pause/resume
- R: restart
- Buttons: Start/Resume, Pause/Resume, Restart

## Behavior

- The game starts paused and shows a how-to-play overlay.
- Eat red food to grow and earn 10 points per food.
- Hitting a wall or yourself ends the game and shows a final score.
- Restart begins a new game immediately.

## Files

- `index.html` — page structure
- `styles.css` — responsive visual theme
- `game.js` — game logic and rendering
