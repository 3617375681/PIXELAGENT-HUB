# Pixel Memory Match

A simple offline memory game built with HTML, CSS, and vanilla JavaScript.

## How to run
Open `index.html` in any modern browser. No server, install, or network connection required.

## How to play
- Click or tap a card to flip it.
- Flip two cards at a time.
- If the colors match, the pair stays open.
- If they do not match, they flip back after a short delay.
- The move counter goes up after each pair of flips.
- Match all 8 pairs to see the win message.
- Use the **New Game** button to shuffle and restart.

## Keyboard access
- Press `Tab` to move between the New Game button and cards.
- Press `Enter` or `Space` to activate buttons.
- Each card has an accessible label announcing its position and color.
