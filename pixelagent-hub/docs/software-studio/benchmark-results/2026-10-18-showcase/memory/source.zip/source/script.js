(() => {
  'use strict';

  const board = document.getElementById('game-board');
  const moveCount = document.getElementById('move-count');
  const winMessage = document.getElementById('win-message');
  const newGameBtn = document.getElementById('new-game');

  const pairColors = [
    { id: 0, name: 'red', color: '#ef476f' },
    { id: 1, name: 'orange', color: '#f78c6b' },
    { id: 2, name: 'yellow', color: '#ffd166' },
    { id: 3, name: 'green', color: '#06d6a0' },
    { id: 4, name: 'teal', color: '#118ab2' },
    { id: 5, name: 'blue', color: '#457b9d' },
    { id: 6, name: 'purple', color: '#b388eb' },
    { id: 7, name: 'pink', color: '#f15bb5' },
  ];

  let cards = [];
  let firstCard = null;
  let secondCard = null;
  let lockBoard = false;
  let moves = 0;
  let matchedPairs = 0;
  let timeoutId = null;

  function shuffle(array) {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  function createCardData() {
    const deck = [];
    pairColors.forEach((pair) => {
      deck.push({ pairId: pair.id, name: pair.name, color: pair.color, matched: false });
      deck.push({ pairId: pair.id, name: pair.name, color: pair.color, matched: false });
    });
    return shuffle(deck);
  }

  function renderBoard() {
    if (timeoutId) {
      clearTimeout(timeoutId);
      timeoutId = null;
    }

    board.innerHTML = '';
    cards = createCardData();
    firstCard = null;
    secondCard = null;
    lockBoard = false;
    moves = 0;
    matchedPairs = 0;
    updateMoveDisplay();
    winMessage.textContent = '';
    winMessage.classList.remove('visible');

    cards.forEach((card, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'card';
      button.dataset.index = String(index);
      button.style.setProperty('--card-color', card.color);
      button.setAttribute('aria-label', `Card ${index + 1}: face down`);
      button.setAttribute('aria-pressed', 'false');

      const inner = document.createElement('span');
      inner.className = 'card-inner';

      const back = document.createElement('span');
      back.className = 'card-face card-back';
      back.setAttribute('aria-hidden', 'true');
      back.textContent = '?';

      const front = document.createElement('span');
      front.className = 'card-face card-front';
      front.setAttribute('aria-hidden', 'true');

      inner.appendChild(back);
      inner.appendChild(front);
      button.appendChild(inner);
      button.addEventListener('click', () => handleCardClick(button, card));
      board.appendChild(button);
    });
  }

  function updateMoveDisplay() {
    moveCount.textContent = String(moves);
  }

  function flipCard(button, card) {
    button.classList.add('flipped');
    button.setAttribute('aria-pressed', 'true');
    button.setAttribute('aria-label', `Card ${Number(button.dataset.index) + 1}: ${card.name}`);
  }

  function unflipCard(button) {
    button.classList.remove('flipped');
    button.setAttribute('aria-pressed', 'false');
    button.setAttribute('aria-label', `Card ${Number(button.dataset.index) + 1}: face down`);
  }

  function markMatched(button, card) {
    button.classList.add('matched');
    button.setAttribute('aria-pressed', 'true');
    button.setAttribute('aria-label', `Card ${Number(button.dataset.index) + 1}: ${card.name}, matched`);
  }

  function handleCardClick(button, card) {
    if (lockBoard) return;
    if (button.classList.contains('flipped') || card.matched) return;
    if (firstCard && firstCard.button === button) return;

    if (!firstCard) {
      firstCard = { button, card };
      flipCard(button, card);
      return;
    }

    secondCard = { button, card };
    flipCard(button, card);
    moves += 1;
    updateMoveDisplay();

    if (firstCard.card.pairId === secondCard.card.pairId) {
      firstCard.card.matched = true;
      secondCard.card.matched = true;
      markMatched(firstCard.button, firstCard.card);
      markMatched(secondCard.button, secondCard.card);
      matchedPairs += 1;
      firstCard = null;
      secondCard = null;

      if (matchedPairs === pairColors.length) {
        winMessage.textContent = `You won in ${moves} moves!`;
        winMessage.classList.add('visible');
      }
    } else {
      lockBoard = true;
      const first = firstCard;
      const second = secondCard;
      timeoutId = setTimeout(() => {
        unflipCard(first.button);
        unflipCard(second.button);
        firstCard = null;
        secondCard = null;
        lockBoard = false;
        timeoutId = null;
      }, 800);
      firstCard = null;
      secondCard = null;
    }
  }

  function startNewGame() {
    renderBoard();
    newGameBtn.focus();
  }

  newGameBtn.addEventListener('click', startNewGame);
  document.addEventListener('DOMContentLoaded', renderBoard);
})();
