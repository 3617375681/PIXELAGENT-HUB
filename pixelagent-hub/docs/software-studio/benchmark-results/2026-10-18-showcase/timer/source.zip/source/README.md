# Pixel Pomodoro Timer

A small offline browser pomodoro timer with a pixel-art theme. Work sessions default to 25 minutes and breaks to 5 minutes.

## How to run

Open index.html in any modern browser. No build step, network access, or external dependencies are required.

## Features

- Start, pause, and reset controls with keyboard and visible focus states
- Large countdown display with work and break mode labels
- Automatic mode switching when the countdown reaches zero
- Responsive centered card layout that works from 360px wide
- Drift-resistant timestamp-based countdown

## File structure

- index.html - page structure
- styles.css - pixel-themed responsive styling
- script.js - timer logic and event wiring
