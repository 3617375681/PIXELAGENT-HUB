document.addEventListener('DOMContentLoaded', () => {
  const WORK_DURATION = 25 * 60;
  const BREAK_DURATION = 5 * 60;
  const countdownEl = document.getElementById('countdown');
  const modeLabelEl = document.getElementById('mode-label');
  const startBtn = document.getElementById('start-btn');
  const pauseBtn = document.getElementById('pause-btn');
  const resetBtn = document.getElementById('reset-btn');
  const statusEl = document.getElementById('timer-status');

  let mode = 'work';
  let remainingSeconds = WORK_DURATION;
  let timerId = null;
  let isRunning = false;
  let lastTick = 0;

  const durationForMode = (m) => m === 'work' ? WORK_DURATION : BREAK_DURATION;
  const otherMode = (m) => m === 'work' ? 'break' : 'work';

  function formatTime(totalSeconds) {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }

  function updateDisplay() {
    countdownEl.textContent = formatTime(remainingSeconds);
    modeLabelEl.textContent = mode === 'work' ? 'Work Mode' : 'Break Mode';
  }

  function updateControls() {
    startBtn.disabled = isRunning;
    pauseBtn.disabled = !isRunning;
  }

  function setStatus(message) {
    statusEl.textContent = message;
  }

  function startTimer() {
    if (isRunning) return;
    isRunning = true;
    lastTick = Date.now();
    timerId = setInterval(tick, 250);
    updateControls();
    setStatus(`${mode === 'work' ? 'Work' : 'Break'} timer running`);
  }

  function pauseTimer() {
    if (!isRunning) return;
    isRunning = false;
    clearInterval(timerId);
    timerId = null;
    updateControls();
    setStatus(`${mode === 'work' ? 'Work' : 'Break'} timer paused`);
  }

  function resetTimer() {
    pauseTimer();
    remainingSeconds = durationForMode(mode);
    updateDisplay();
    setStatus(`${mode === 'work' ? 'Work' : 'Break'} timer reset`);
  }

  function tick() {
    const now = Date.now();
    const delta = Math.floor((now - lastTick) / 1000);
    if (delta < 1) return;
    lastTick += delta * 1000;
    remainingSeconds = Math.max(0, remainingSeconds - delta);
    updateDisplay();
    if (remainingSeconds <= 0) {
      clearInterval(timerId);
      timerId = null;
      isRunning = false;
      mode = otherMode(mode);
      remainingSeconds = durationForMode(mode);
      updateDisplay();
      updateControls();
      setStatus(`${mode === 'work' ? 'Work' : 'Break'} timer ready`);
    }
  }

  startBtn.addEventListener('click', startTimer);
  pauseBtn.addEventListener('click', pauseTimer);
  resetBtn.addEventListener('click', resetTimer);

  updateDisplay();
  updateControls();
  setStatus('Work timer ready');
});