# Pixel Color Palette Generator

A small offline browser app that shows five color swatches with hex codes, generates fresh harmonious palettes, and lets you lock individual colors while generating new ones.

## Features

- Five color swatches with visible hex labels
- One-click harmonious palette generation
- Lock/unlock toggle on each swatch
- Keyboard-accessible, labeled controls
- Responsive layout from 360px wide and up
- No dependencies, packages, or network requests

## How to Run

Open `index.html` in any modern browser. No build step or local server is required.

## How It Works

The app stores a five-color palette in memory. The Generate button creates a new palette using HSL color harmony offsets. Locked colors are left unchanged, and if any colors are locked, generation anchors around the first locked color for a more cohesive result.
