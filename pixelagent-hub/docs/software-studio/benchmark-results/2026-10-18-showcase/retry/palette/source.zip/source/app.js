"use strict";

const paletteEl = document.getElementById("palette");
const generateBtn = document.getElementById("generateBtn");

const palette = Array.from({ length: 5 }, () => ({ hex: "#000000", locked: false }));

const OFFSETS = [0, 30, 62, 180, 210];

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function hslToHex(h, s, l) {
  s /= 100;
  l /= 100;
  const k = (n) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  const toHex = (x) => Math.round(255 * x).toString(16).padStart(2, "0");
  return `#${toHex(f(0))}${toHex(f(8))}${toHex(f(4))}`;
}

function hexToHsl(hex) {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);

    if (max === r) {
      h = ((g - b) / d + (g < b ? 6 : 0)) * 60;
    } else if (max === g) {
      h = ((b - r) / d + 2) * 60;
    } else {
      h = ((r - g) / d + 4) * 60;
    }
  }

  return { h: Math.round(h), s: Math.round(s * 100), l: Math.round(l * 100) };
}

function renderPalette() {
  paletteEl.innerHTML = "";

  palette.forEach((color, index) => {
    const swatch = document.createElement("div");
    swatch.className = "swatch";
    swatch.style.backgroundColor = color.hex;
    swatch.setAttribute("role", "listitem");

    const hexLabel = document.createElement("span");
    hexLabel.className = "hex";
    hexLabel.textContent = color.hex.toUpperCase();

    const lockButton = document.createElement("button");
    lockButton.type = "button";
    lockButton.className = "lock-btn";
    lockButton.setAttribute("aria-pressed", String(color.locked));
    lockButton.setAttribute("aria-label", `${color.locked ? "Unlock" : "Lock"} ${color.hex.toUpperCase()}`);
    lockButton.textContent = color.locked ? "🔒" : "🔓";
    lockButton.addEventListener("click", () => {
      color.locked = !color.locked;
      renderPalette();
    });

    swatch.append(hexLabel, lockButton);
    paletteEl.appendChild(swatch);
  });
}

function generatePalette() {
  const lockedColors = palette.filter((color) => color.locked);
  let baseHue = randomInt(0, 360);
  let saturation = randomInt(58, 72);
  let lightness = randomInt(45, 62);

  if (lockedColors.length > 0) {
    const firstLock = hexToHsl(lockedColors[0].hex);
    baseHue = firstLock.h;
    saturation = firstLock.s;
    lightness = firstLock.l;
  }

  palette.forEach((color, index) => {
    if (color.locked) return;

    const hue = (baseHue + OFFSETS[index]) % 360;
    const s = Math.min(100, Math.max(35, saturation + randomInt(-4, 4)));
    const l = Math.min(80, Math.max(28, lightness + randomInt(-4, 4)));
    color.hex = hslToHex(hue, s, l);
  });

  renderPalette();
}

generateBtn.addEventListener("click", generatePalette);

// Create the initial palette on page load.
generatePalette();
