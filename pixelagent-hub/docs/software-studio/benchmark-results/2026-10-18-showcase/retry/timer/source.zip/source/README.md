# Pixel Pomodoro Timer

An offline browser pomodoro timer with a pixel-art inspired interface. Work sessions last 25 minutes, break sessions last 5 minutes, and the timer automatically switches modes when a session ends.

## How to run

Open `index.html` in any modern browser. No build tools, packages, or network access are required.

## Files

- `index.html` - semantic card layout with countdown, mode label, status message, and controls.
- `styles.css` - responsive pixel theme with a cohesive dark palette, visible focus/hover/pressed states, and layout from 360px wide.
- `script.js` - timer state machine, `setInterval` countdown, start/pause/reset event listeners, and automatic mode switching.

## Controls

- **Start/Pause** - toggles the current countdown.
- **Reset** - clears any active timer and returns to a 25-minute work session.

All controls are native buttons and support keyboard activation with Enter or Space. The countdown and status updates are announced politely to screen readers.

## Behavior

- Starts in Work mode at 25:00.
- When work ends, switches to Break mode at 5:00 and continues running.
- When break ends, switches back to Work mode at 25:00 and continues running.
- Reset always returns to Work mode at 25:00 and stops the timer.
