(function () {
  "use strict";

  const WORK_SECONDS = 25 * 60;
  const BREAK_SECONDS = 5 * 60;

  const startPauseButton = document.getElementById("start-pause");
  const resetButton = document.getElementById("reset");
  const countdownDisplay = document.getElementById("countdown");
  const modeLabel = document.getElementById("mode-label");
  const statusLabel = document.getElementById("status");

  let isWork = true;
  let timeLeft = WORK_SECONDS;
  let timerId = null;
  let isRunning = false;

  function formatTime(totalSeconds) {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return String(minutes).padStart(2, "0") + ":" + String(seconds).padStart(2, "0");
  }

  function updateDisplay() {
    const formatted = formatTime(timeLeft);
    countdownDisplay.textContent = formatted;
    modeLabel.textContent = isWork ? "Work mode" : "Break mode";
    document.title = formatted + " - " + (isWork ? "Work" : "Break") + " | Pixel Pomodoro";
  }

  function startTimer() {
    if (timerId !== null) return;

    timerId = setInterval(() => {
      timeLeft -= 1;
      if (timeLeft <= 0) {
        handleModeComplete();
      } else {
        updateDisplay();
      }
    }, 1000);
  }

  function pauseTimer() {
    if (timerId !== null) {
      clearInterval(timerId);
      timerId = null;
    }
  }

  function handleModeComplete() {
    if (isWork) {
      statusLabel.textContent = "Work session complete! Take a break.";
      isWork = false;
      timeLeft = BREAK_SECONDS;
    } else {
      statusLabel.textContent = "Break complete! Back to work.";
      isWork = true;
      timeLeft = WORK_SECONDS;
    }
    updateDisplay();
  }

  function toggleTimer() {
    if (isRunning) {
      pauseTimer();
      isRunning = false;
      startPauseButton.textContent = "Start";
      startPauseButton.setAttribute("aria-label", "Start timer");
      statusLabel.textContent = "Paused.";
    } else {
      startTimer();
      isRunning = true;
      startPauseButton.textContent = "Pause";
      startPauseButton.setAttribute("aria-label", "Pause timer");
      statusLabel.textContent = "";
    }
  }

  function resetTimer() {
    pauseTimer();
    isRunning = false;
    isWork = true;
    timeLeft = WORK_SECONDS;
    startPauseButton.textContent = "Start";
    startPauseButton.setAttribute("aria-label", "Start timer");
    statusLabel.textContent = "Timer reset.";
    updateDisplay();
  }

  startPauseButton.addEventListener("click", toggleTimer);
  resetButton.addEventListener("click", resetTimer);

  updateDisplay();
})();
