# Pixel Tip Calculator

An offline browser tip calculator with a pixel-art interface. Enter a bill amount, choose a 10%, 15%, or 20% tip, and set the number of people. The app shows the tip amount and total per person.

## How to run

Open `index.html` directly in any modern browser. No packages, network access, or server required.

## Files

- `index.html` — semantic markup and labeled controls
- `style.css` — responsive pixel-art layout and control states
- `script.js` — tip calculation and event handling

## Features

- Tip percent buttons: 10%, 15%, 20%
- Bill amount and number-of-people inputs
- Live tip amount and total-per-person outputs
- Keyboard-accessible controls with visible focus states
- Responsive layout from 360px wide
