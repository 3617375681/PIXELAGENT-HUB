(function () {
  const billInput = document.getElementById('bill-amount');
  const peopleInput = document.getElementById('people-count');
  const tipButtons = Array.from(document.querySelectorAll('.tip-button'));
  const tipAmountOutput = document.getElementById('tip-amount');
  const totalPerPersonOutput = document.getElementById('total-per-person');

  let selectedTip = 15;

  function formatCurrency(value) {
    return '$' + value.toFixed(2);
  }

  function calculate() {
    const bill = parseFloat(billInput.value);
    const people = parseInt(peopleInput.value, 10);

    if (isNaN(bill) || bill <= 0 || isNaN(people) || people <= 0) {
      tipAmountOutput.textContent = '$0.00';
      totalPerPersonOutput.textContent = '$0.00';
      return;
    }

    const tip = bill * selectedTip / 100;
    const total = bill + tip;
    const perPerson = total / people;

    tipAmountOutput.textContent = formatCurrency(tip);
    totalPerPersonOutput.textContent = formatCurrency(perPerson);
  }

  function selectTip(tip) {
    selectedTip = tip;
    tipButtons.forEach(function (button) {
      const isSelected = Number(button.dataset.tip) === tip;
      button.classList.toggle('is-selected', isSelected);
      button.setAttribute('aria-pressed', isSelected ? 'true' : 'false');
    });
    calculate();
  }

  tipButtons.forEach(function (button) {
    button.addEventListener('click', function () {
      selectTip(Number(button.dataset.tip));
    });
  });

  billInput.addEventListener('input', calculate);
  peopleInput.addEventListener('input', calculate);

  selectTip(15);
})();
