# Offline Pixel Quiz

A tiny offline quiz with a pixel-art style.

## Run

Open `index.html` in any modern web browser. No server, packages, or network access required.

## How to Play

1. Click an answer to lock it. Correct answers add 1 to the score.
2. Click **Next** to advance: first `2 + 2 = ?`, then `3 + 3 = ?`.
3. After the second answer, **Next** shows **Finished**.
4. Click **Restart** to return to the first question and reset the score to 0.

## Files

- `index.html` - quiz structure
- `styles.css` - pixel-style presentation
- `script.js` - quiz state and logic
