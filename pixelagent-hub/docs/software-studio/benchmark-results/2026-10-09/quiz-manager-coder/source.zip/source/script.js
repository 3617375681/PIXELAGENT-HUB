(() => {
  const questionEl = document.getElementById('question');
  const scoreEl = document.getElementById('score');
  const answerA = document.getElementById('answer-a');
  const answerB = document.getElementById('answer-b');
  const nextBtn = document.getElementById('next');
  const restartBtn = document.getElementById('restart');

  let currentQuestion = 0;
  let score = 0;
  let answered = false;

  function updateButtons() {
    const finished = currentQuestion >= 2;
    answerA.disabled = finished || answered;
    answerB.disabled = finished || answered;
    nextBtn.disabled = finished;
  }

  function showQuestion(q) {
    if (q === 0) {
      questionEl.textContent = '2 + 2 = ?';
      answerA.textContent = '4';
      answerB.textContent = '5';
    } else if (q === 1) {
      questionEl.textContent = '3 + 3 = ?';
      answerA.textContent = '5';
      answerB.textContent = '6';
    } else {
      questionEl.textContent = 'Finished';
      answerA.textContent = '';
      answerB.textContent = '';
    }
    answered = false;
    updateButtons();
  }

  function handleAnswer(event) {
    if (answered || currentQuestion >= 2) return;
    const btn = event.currentTarget;
    const correct = (currentQuestion === 0 && btn.id === 'answer-a') ||
                    (currentQuestion === 1 && btn.id === 'answer-b');
    if (correct) {
      score += 1;
      scoreEl.textContent = String(score);
    }
    answered = true;
    updateButtons();
  }

  function handleNext() {
    if (currentQuestion < 2) {
      currentQuestion += 1;
      showQuestion(currentQuestion);
    }
  }

  function handleRestart() {
    currentQuestion = 0;
    score = 0;
    scoreEl.textContent = '0';
    showQuestion(0);
  }

  answerA.addEventListener('click', handleAnswer);
  answerB.addEventListener('click', handleAnswer);
  nextBtn.addEventListener('click', handleNext);
  restartBtn.addEventListener('click', handleRestart);

  showQuestion(0);
})();
