const temperatureInput = document.getElementById('temperature');
const directionSelect = document.getElementById('direction');
const convertButton = document.getElementById('convert');
const resultOutput = document.getElementById('result');

function convertTemperature() {
  const raw = temperatureInput.value.trim();
  if (raw === '') {
    resultOutput.textContent = 'Error';
    return;
  }
  const value = Number(raw);
  if (!Number.isFinite(value)) {
    resultOutput.textContent = 'Error';
    return;
  }
  let converted;
  if (directionSelect.value === 'c-to-f') {
    converted = value * 9 / 5 + 32;
  } else if (directionSelect.value === 'f-to-c') {
    converted = (value - 32) * 5 / 9;
  } else {
    resultOutput.textContent = 'Error';
    return;
  }
  resultOutput.textContent = converted.toFixed(2);
}

convertButton.addEventListener('click', convertTemperature);
temperatureInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    convertTemperature();
  }
});