# Pixel Temperature Converter

A small offline pixel-style temperature converter built with HTML, CSS, and plain JavaScript.

## Usage

1. Open `index.html` in a modern browser.
2. Enter a number in the Temperature field.
3. Choose a direction: `c-to-f` for Celsius to Fahrenheit, or `f-to-c` for Fahrenheit to Celsius.
4. Click Convert or press Enter while the input is focused.
5. The result shows a numeric value with exactly two decimals and no units. Invalid input shows `Error`.

## Conversion formulas

- Celsius to Fahrenheit: `x * 9 / 5 + 32`
- Fahrenheit to Celsius: `(x - 32) * 5 / 9`

## Validation

- Empty input, non-numeric input, or non-finite values such as `Infinity` produce `Error`.
- Results are formatted with `Number.prototype.toFixed(2)`.

## Files

- `index.html` — accessible markup and labeled controls
- `styles.css` — pixel-style theme and focus states
- `script.js` — conversion logic and keyboard handling

## Offline use

No packages, network requests, storage, or external assets are used. All paths are relative.