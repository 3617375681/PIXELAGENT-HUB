const leftInput = document.getElementById('left');
const rightInput = document.getElementById('right');
const operationSelect = document.getElementById('operation');
const calculateButton = document.getElementById('calculate');
const resultOutput = document.getElementById('result');

function readNumber(input) {
  const value = input.value.trim();
  if (value === '') return null;

  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function compute(left, right, operation) {
  switch (operation) {
    case 'add':
      return left + right;
    case 'subtract':
      return left - right;
    case 'multiply':
      return left * right;
    case 'divide':
      if (right === 0) return null;
      return left / right;
    default:
      return null;
  }
}

calculateButton.addEventListener('click', () => {
  const left = readNumber(leftInput);
  const right = readNumber(rightInput);

  if (left === null || right === null) {
    resultOutput.textContent = 'Error';
    return;
  }

  const value = compute(left, right, operationSelect.value);
  resultOutput.textContent = Number.isFinite(value) ? String(value) : 'Error';
});
