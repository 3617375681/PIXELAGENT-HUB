# Pixel Two-Number Calculator

A small offline calculator built with HTML, CSS, and plain JavaScript.

## Files

- `index.html` - page structure and labeled controls
- `style.css` - pixel/retro styling
- `script.js` - calculator behavior

## Usage

Open `index.html` in any modern browser. Enter a left and right number, choose an operation, and click **Calculate** or press Enter while the button is focused.

## Behavior

- Supports negative numbers
- Rejects empty or non-finite inputs with exact text `Error`
- Division by zero displays exact text `Error`
- Result output shows only the numeric result, with no label

## Constraints

- No packages, network requests, storage, or external assets
- Uses `addEventListener` instead of inline HTML event handlers
