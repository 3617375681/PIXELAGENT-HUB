const calculator = document.getElementById('calculator');
const left = document.getElementById('left');
const right = document.getElementById('right');
const operation = document.getElementById('operation');
const result = document.getElementById('result');

function getNumber(input) {
  const raw = input.value.trim();
  if (raw === '') {
    return null;
  }

  const num = Number(raw);
  return Number.isFinite(num) ? num : null;
}

function compute() {
  const a = getNumber(left);
  const b = getNumber(right);

  if (a === null || b === null) {
    result.textContent = 'Error';
    return;
  }

  let value;
  switch (operation.value) {
    case 'add':
      value = a + b;
      break;
    case 'subtract':
      value = a - b;
      break;
    case 'multiply':
      value = a * b;
      break;
    case 'divide':
      if (b === 0) {
        result.textContent = 'Error';
        return;
      }
      value = a / b;
      break;
    default:
      result.textContent = 'Error';
      return;
  }

  result.textContent = String(value);
}

calculator.addEventListener('submit', (event) => {
  event.preventDefault();
  compute();
});
