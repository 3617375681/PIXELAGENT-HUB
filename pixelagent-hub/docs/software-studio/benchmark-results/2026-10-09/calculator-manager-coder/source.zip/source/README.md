# Pixel Two-Number Calculator

A tiny offline pixel-style calculator built with HTML, CSS, and vanilla JavaScript.

## Run

Open `index.html` directly in any modern browser. No server, packages, network access, or storage required.

## Controls

- `left`: first number input
- `right`: second number input
- `operation`: select `add`, `subtract`, `multiply`, or `divide`
- `calculate`: submit button
- `result`: output element, initially `0`

## Behavior

- Supports positive, negative, and decimal numbers.
- Outputs only the numeric result, with no extra label text.
- Rejects empty or non-finite inputs with the exact text `Error`.
- Rejects division by zero with the exact text `Error`.

## Files

- `index.html`: page structure and controls
- `style.css`: pixel-style retro theme
- `script.js`: calc logic and event handling
- `README.md`: this file
