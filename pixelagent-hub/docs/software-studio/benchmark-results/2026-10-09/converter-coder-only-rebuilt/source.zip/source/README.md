# Pixel Temperature Converter

An offline, dependency-free temperature converter built with plain HTML, CSS, and JavaScript.

## Usage

1. Open `index.html` in a browser.
2. Enter a temperature in the **Temperature** field.
3. Choose **Celsius to Fahrenheit** or **Fahrenheit to Celsius**.
4. Press **Convert** or Enter.
5. Read the numeric result with exactly two decimals, without units.

Empty or invalid/non-finite inputs display exactly `Error`.

## Formulas

- Celsius to Fahrenheit: `°F = °C × 9/5 + 32`
- Fahrenheit to Celsius: `°C = (°F − 32) × 5/9`

## Notes

- No packages, imports, storage, or network requests.
- Pixel-style UI is achieved with CSS only.
- Keyboard accessible labeled controls and visible focus styles are included.
