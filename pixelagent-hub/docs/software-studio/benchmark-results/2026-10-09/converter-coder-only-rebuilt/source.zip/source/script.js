const temperatureInput = document.getElementById('temperature');
const directionSelect = document.getElementById('direction');
const convertButton = document.getElementById('convert');
const resultOutput = document.getElementById('result');

function celsiusToFahrenheit(c) {
  return c * 9 / 5 + 32;
}

function fahrenheitToCelsius(f) {
  return (f - 32) * 5 / 9;
}

function convert() {
  const rawValue = temperatureInput.value.trim();
  if (rawValue === '') {
    resultOutput.textContent = 'Error';
    return;
  }
  const value = Number(rawValue);
  if (!Number.isFinite(value)) {
    resultOutput.textContent = 'Error';
    return;
  }
  const result = directionSelect.value === 'c-to-f'
    ? celsiusToFahrenheit(value)
    : fahrenheitToCelsius(value);
  resultOutput.textContent = result.toFixed(2);
}

convertButton.addEventListener('click', convert);
temperatureInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') convert();
});
directionSelect.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') convert();
});
