(function () {
  'use strict';

  var questionEl = document.getElementById('question');
  var scoreEl = document.getElementById('score');
  var answerA = document.getElementById('answer-a');
  var answerB = document.getElementById('answer-b');
  var nextBtn = document.getElementById('next');
  var restartBtn = document.getElementById('restart');

  var questions = [
    { text: '2 + 2 = ?', a: '4', b: '5', correct: 'a' },
    { text: '3 + 3 = ?', a: '5', b: '6', correct: 'b' }
  ];

  var current = 0;
  var score = 0;
  var answered = false;
  var finished = false;

  function renderQuestion() {
    var q = questions[current];
    questionEl.textContent = q.text;
    answerA.textContent = q.a;
    answerB.textContent = q.b;
    answerA.disabled = false;
    answerB.disabled = false;
    nextBtn.disabled = true;
    answered = false;
  }

  function lockAnswers() {
    answerA.disabled = true;
    answerB.disabled = true;
  }

  function handleAnswer(choice) {
    if (answered || finished) {
      return;
    }
    answered = true;
    if (choice === questions[current].correct) {
      score += 1;
      scoreEl.textContent = score;
    }
    lockAnswers();
    nextBtn.disabled = false;
  }

  function handleNext() {
    if (!answered || finished) {
      return;
    }
    if (current === 0) {
      current = 1;
      renderQuestion();
    } else if (current === 1) {
      finished = true;
      questionEl.textContent = 'Finished';
      lockAnswers();
      nextBtn.disabled = true;
    }
  }

  function handleRestart() {
    current = 0;
    score = 0;
    scoreEl.textContent = score;
    finished = false;
    renderQuestion();
  }

  answerA.addEventListener('click', function () {
    handleAnswer('a');
  });
  answerB.addEventListener('click', function () {
    handleAnswer('b');
  });
  nextBtn.addEventListener('click', handleNext);
  restartBtn.addEventListener('click', handleRestart);

  renderQuestion();
})();
