# Pixel Quiz

An offline, pixel-style two-question math quiz built with HTML, CSS, and plain JavaScript.

## How to run
- Open `index.html` in any modern browser. No server, build step, or internet connection required.

## Controls
- Click or tab to an answer button and press Enter/Space to choose it.
- Use the `Next` button to advance after answering.
- Use the `Restart` button to return to the first question with a score of 0.

## Structure
- `index.html` — page markup and labels
- `styles.css` — pixel/retro styling
- `script.js` — quiz state and event listeners

## Notes
- Score increments only once per question and only for the correct answer.
- No storage or external dependencies.
