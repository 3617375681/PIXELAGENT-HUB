# Pixel Counter

An offline pixel-style counter built with only HTML, CSS, and JavaScript.

## Run

Open `index.html` in any modern browser. No network or build steps are required.

## Files

- `index.html` — semantic page structure, `output` element with `id` of `count`, and labeled buttons
- `styles.css` — pixel-style layout, keyboard focus indicators, and button states
- `script.js` — counter logic using `addEventListener`

## Controls

- **Increase +1** adds one to the count
- **Decrease -1** subtracts one from the count
- **Reset to 0** resets the count to zero

All buttons are keyboard accessible. Use the `Tab` key to move focus and `Enter` or `Space` to activate.

## Notes

- Supports negative integers
- No dependencies, storage, or external assets
- Total source under 200 lines