"use strict";

let count = 0;

const countOutput = document.getElementById("count");
const increaseButton = document.getElementById("increase");
const decreaseButton = document.getElementById("decrease");
const resetButton = document.getElementById("reset");

function updateDisplay() {
  countOutput.textContent = count;
}

increaseButton.addEventListener("click", () => {
  count += 1;
  updateDisplay();
});

decreaseButton.addEventListener("click", () => {
  count -= 1;
  updateDisplay();
});

resetButton.addEventListener("click", () => {
  count = 0;
  updateDisplay();
});

updateDisplay();