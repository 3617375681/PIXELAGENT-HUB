# Pixel Counter

A small offline counter built with HTML, CSS, and JavaScript.

## Features

- Starts at 0
- Increase, decrease, and reset buttons
- Supports negative integers
- Pixel-style UI
- Keyboard accessible buttons
- No dependencies or network access

## Usage

1. Open `index.html` in any modern browser.
2. Click or tab to the buttons and press Enter/Space.
3. Use Increase +1, Decrease -1, or Reset.

## Files

- `index.html` - page structure
- `styles.css` - pixel visual style
- `script.js` - counter logic

No build step or server required.