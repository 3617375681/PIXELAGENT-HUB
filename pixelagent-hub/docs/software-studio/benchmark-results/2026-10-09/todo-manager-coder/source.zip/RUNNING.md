# Run this project

Open preview/index.html in a modern browser. No installation is required.

Source files are in source/. Build success is not browser interaction verification.
