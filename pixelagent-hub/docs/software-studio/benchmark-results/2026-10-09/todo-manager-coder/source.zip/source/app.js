(() => {
  "use strict";

  const input = document.getElementById("todo-input");
  const addButton = document.getElementById("todo-add");
  const list = document.getElementById("todo-list");
  const total = document.getElementById("todo-total");
  const remaining = document.getElementById("remaining");
  const tasks = [];
  let nextId = 1;

  const updateCounts = () => {
    total.textContent = tasks.length;
    remaining.textContent = tasks.filter((task) => !task.completed).length;
  };

  const createTaskRow = (task) => {
    const li = document.createElement("li");
    li.className = "task-row";
    li.id = "task-item-" + task.id;

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.id = "todo-check-" + task.id;
    checkbox.className = "check";
    checkbox.setAttribute("aria-label", "Mark " + task.text + " complete");

    const label = document.createElement("label");
    label.className = "task-text";
    label.setAttribute("for", checkbox.id);

    const span = document.createElement("span");
    span.id = "todo-text-" + task.id;
    span.textContent = task.text;
    label.appendChild(span);

    const deleteButton = document.createElement("button");
    deleteButton.type = "button";
    deleteButton.id = "todo-delete-" + task.id;
    deleteButton.className = "delete";
    deleteButton.textContent = "✕";
    deleteButton.setAttribute("aria-label", "Delete " + task.text);

    li.append(checkbox, label, deleteButton);
    return li;
  };

  const addTask = () => {
    const text = input.value.trim();
    if (!text) return;

    const task = { id: nextId++, text, completed: false };
    tasks.push(task);

    const row = createTaskRow(task);

    row.querySelector("input").addEventListener("change", (event) => {
      task.completed = event.target.checked;
      row.classList.toggle("completed", task.completed);
      updateCounts();
    });

    row.querySelector("button").addEventListener("click", () => {
      row.remove();
      tasks.splice(tasks.indexOf(task), 1);
      updateCounts();
    });

    list.appendChild(row);
    updateCounts();
    input.value = "";
    input.focus();
  };

  addButton.addEventListener("click", addTask);
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") addTask();
  });

  updateCounts();
})();
