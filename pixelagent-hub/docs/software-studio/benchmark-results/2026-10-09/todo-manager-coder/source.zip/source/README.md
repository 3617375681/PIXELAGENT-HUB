# Offline Pixel-Style Task List

A small offline to-do app built with HTML, CSS, and vanilla JavaScript. Task state lives only in memory, so refreshing the page resets all tasks.

## Features

- Add tasks from a labeled input; text is trimmed and blank input is ignored.
- Total and remaining counters update as integer-only values.
- Each task has a checkbox and delete button with accessible labels.
- New tasks get increasing numeric IDs starting at 1.
- Pixel-style UI uses only local CSS and system monospace fonts.

## Run

Open `index.html` in any modern browser. No server, build step, or network access is required.

## Keyboard Usage

- Focus moves naturally among input, add button, task checkboxes, and delete buttons.
- Press Enter in the input to add a task.
- Use Space to toggle a checkbox, backed by the browser default.

## File List

- `index.html`: semantic page structure.
- `styles.css`: pixel-styled, responsive layout.
- `app.js`: all in-memory task state and DOM behavior.
