const form = document.getElementById('todo-form');
const input = document.getElementById('todo-input');
const list = document.getElementById('todo-list');
const totalEl = document.getElementById('todo-total');
const remainingEl = document.getElementById('remaining');

let tasks = [];
let nextId = 1;

function updateCounts() {
  totalEl.textContent = tasks.length;
  remainingEl.textContent = tasks.filter(task => !task.completed).length;
}

function render() {
  list.innerHTML = '';
  for (const task of tasks) {
    const li = document.createElement('li');
    if (task.completed) li.classList.add('completed');

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.id = `todo-check-${task.id}`;
    checkbox.checked = task.completed;
    checkbox.setAttribute('aria-label', `Mark ${task.text} complete`);

    checkbox.addEventListener('change', () => {
      task.completed = checkbox.checked;
      li.classList.toggle('completed', task.completed);
      updateCounts();
    });

    const span = document.createElement('span');
    span.id = `todo-text-${task.id}`;
    span.textContent = task.text;

    const deleteBtn = document.createElement('button');
    deleteBtn.id = `todo-delete-${task.id}`;
    deleteBtn.className = 'delete';
    deleteBtn.textContent = 'Delete';
    deleteBtn.addEventListener('click', () => {
      tasks = tasks.filter(t => t.id !== task.id);
      render();
      updateCounts();
    });

    li.append(checkbox, span, deleteBtn);
    list.appendChild(li);
  }
  updateCounts();
}

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  tasks.push({ id: nextId++, text, completed: false });
  input.value = '';
  render();
});

updateCounts();
