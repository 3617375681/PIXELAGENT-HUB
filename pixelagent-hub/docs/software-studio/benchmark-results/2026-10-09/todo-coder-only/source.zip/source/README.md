# Pixel Task List

A tiny offline task list with a pixel-style interface. Built with HTML, CSS, and vanilla JavaScript only.

## Features
- Add tasks by typing text and pressing Enter or clicking Add.
- Input is trimmed; blank input is ignored.
- Each task has a checkbox and a delete button.
- Total and incomplete counts update live.
- State is kept in memory only, so refreshing clears tasks.

## Usage
Open index.html in any modern browser.

## Files
- index.html - page structure and labels
- styles.css - pixel-style visual theme
- script.js - task state and event handling
